# job_samples
To display examples of my code to potential employers. 
